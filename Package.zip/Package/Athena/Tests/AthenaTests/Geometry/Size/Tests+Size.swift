
import Foundation
import Athena
import XCTest

extension Tests {
    
    func testRect() {
        
//        let r: Rect = Rect.init
        
    }
    
}

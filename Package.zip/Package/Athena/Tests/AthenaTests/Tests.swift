
import Foundation
import XCTest
@testable import Athena

class Tests: XCTest {
    
//    typealias Rect = CGRect
//    typealias Point = CGPoint
//    typealias Size = CGSize
    
}
